const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'menu',
    alias: ['help', 'cmd'],
    category: 'main',
    use: 'all',
    
    run: async ({ adibot, m, senderNumber, prefix, functions }) => {
        try {
            const date = new Date().toLocaleString('id-ID', {
                timeZone: 'Asia/Jakarta',
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            const uptime = functions.getUptime();
            const greeting = functions.getGreeting();
            const quotes = [
                "Kode yang bagus adalah puisi terbaik.",
                "Satu-satunya cara untuk melakukan pekerjaan hebat adalah dengan mencintai apa yang Anda lakukan.",
                "Kesalahan adalah bukti bahwa Anda sedang mencoba.",
                "Jangan hanya membaca kode, jalankan dan rasakan alurnya."
            ];
            const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

            const fkontak = {
                key: { remoteJid: 'status@broadcast', participant: '0@s.whatsapp.net', fromMe: false, id: global.botName },
                message: { "contactMessage": { "displayName": `${global.botName} - ${date}` } }
            };

            const pluginsDir = path.resolve('./Plugins');
            const categorized = {};
            const uniquePlugins = new Set();

            function readPlugins(dir) {
                const files = fs.readdirSync(dir);
                for (const file of files) {
                    const fullPath = path.join(dir, file);
                    if (fs.statSync(fullPath).isDirectory()) {
                        readPlugins(fullPath);
                    } else if (file.endsWith('.js')) {
                        try {
                            const plugin = require(fullPath);
                            if (plugin.name && plugin.category && !uniquePlugins.has(plugin.name)) {
                                if (!categorized[plugin.category]) {
                                    categorized[plugin.category] = [];
                                }
                                categorized[plugin.category].push(plugin.name);
                                uniquePlugins.add(plugin.name);
                            }
                        } catch (e) {}
                    }
                }
            }
            readPlugins(pluginsDir);

            let menuText = `*${greeting}, @${senderNumber}!*\n\n`;
            menuText += `⏱️ *Uptime Bot:* ${uptime}\n`;
            menuText += `⚙️ *Total Perintah:* ${uniquePlugins.size}\n\n`;
            
            for (const category in categorized) {
                if (category === 'owner' && !global.owner.includes(senderNumber)) continue;
                menuText += `┌─「 *${category.toUpperCase()}* 」\n`;
                menuText += `│- ${prefix}${categorized[category].join(`\n│- ${prefix}`)}\n`;
                menuText += `└─\n\n`;
            }
            
            const footerText = `> ${randomQuote}\n\n*${global.botName} © 2025*`;

            const buttons = [
                { buttonId: `${prefix}owner`, buttonText: { displayText: 'Owner 👑' }, type: 1 },
                { buttonId: `${prefix}ping`, buttonText: { displayText: 'Speed 💨' }, type: 1 }
            ];

            let buttonMessage = {
                caption: menuText,
                footer: footerText,
                buttons: buttons,
                headerType: 4,
                mentions: [m.key.participant || m.key.remoteJid]
            };

            const thumbnailPath = './thumbnail.png';
            if (fs.existsSync(thumbnailPath)) {
                buttonMessage.image = fs.readFileSync(thumbnailPath);
            } else {
                buttonMessage.image = { url: 'https://i.imgur.com/b0SL2rS.jpeg' };
            }

            await adibot.sendMessage(
                m.key.remoteJid,
                buttonMessage,
                { quoted: fkontak }
            );

        } catch (e) {
            console.error("Error di menu.js:", e);
            m.reply(global.mess.error);
        }
    }
};