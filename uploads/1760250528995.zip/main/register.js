module.exports = {
    name: 'register',
    category: 'main',
    isPublic: true,
    use: 'all',

    run: async ({ adibot, m, args, sender, senderNumber, prefix, functions }) => {
        if (functions.isRegistered(senderNumber)) {
            return m.reply(`✅ Anda sudah terdaftar! Tidak perlu mendaftar lagi.`);
        }

        if (global.otpSessions.has(senderNumber)) {
            return m.reply('⏳ Anda sedang dalam sesi registrasi. Silakan selesaikan verifikasi OTP Anda atau tunggu 5 menit hingga sesi berakhir.');
        }

        const name = args[0];
        const age = parseInt(args[1]);

        if (!name || !age || age < 5 || age > 100) {
            return m.reply(`⚠️ Format salah!\n\nGunakan: *${prefix}register Nama Umur*\nContoh: *${prefix}register Budi 18*`);
        }

        const otp = Math.floor(1000 + Math.random() * 9000).toString();
        
        const session = {
            otp: otp,
            name: name,
            age: age,
            retries: 3,
            timestamp: Date.now()
        };

        global.otpSessions.set(senderNumber, session);

        try {
            await adibot.sendMessage(sender, { text: `🔐 Kode verifikasi (OTP) Anda adalah: *${otp}*\n\nJangan berikan kode ini kepada siapapun.` });
            
            await m.reply(`🔑 Kode OTP telah dikirim ke chat pribadi Anda. Silakan periksa dan balas dengan 4 digit kode tersebut untuk menyelesaikan registrasi. Kode berlaku selama 5 menit.`);
        } catch (e) {
            console.error("Gagal mengirim pesan OTP:", e);
            m.reply("❌ Gagal mengirim kode OTP. Pastikan Anda tidak memblokir bot.");
            global.otpSessions.delete(senderNumber);
        }
    }
};