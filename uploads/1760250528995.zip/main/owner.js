module.exports = {
    name: 'owner',
    category: 'main',
    use: 'all',

    run: async ({ adibot, m, from }) => {
        for (let no of global.owner) {
            await adibot.sendMessage(from, {
                contacts: {
                    displayName: "Owner " + global.botName,
                    contacts: [{
                        vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Owner Bot\nTEL;type=CELL;type=VOICE;waid=${no}:+${no}\nEND:VCARD`,
                    }],
                },
            });
        }
    }
};