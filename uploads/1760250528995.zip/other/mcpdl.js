const axios = require("axios");
const cheerio = require("cheerio");

async function scrapeMcpedlSearch(query) {
  try {
    const { data } = await axios.get(`https://mcpedl.org/?s=${encodeURIComponent(query)}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    });
    const $ = cheerio.load(data);
    const result = [];

    $("article.g-block").each((i, el) => {
      const title = $(el).find(".entry-title a").text().trim();
      const link = $(el).find(".entry-title a").attr("href");
      let image = $(el).find(".post-thumbnail img").attr("data-srcset") || $(el).find(".post-thumbnail img").attr("src");
      if (image && image.includes(",")) {
        image = image.split(",")[0].split(" ")[0];
      }
      const rating = $(el).find(".rating-wrapper span").text().trim();
      if (title && link) {
          result.push({ title, link, image, rating });
      }
    });

    return result;
  } catch (error) {
    throw new Error("Failed to search MCPEDL.");
  }
}

module.exports = {
    name: 'mcpedl',
    alias: ['mcsearch', 'mcpedlsearch'],
    category: 'other',
    use: 'all',

    run: async ({ adibot, m, q }) => {
        if (!q) {
            return m.reply('Please provide a search query.\n\n*Example:* .mcpedl shaders');
        }

        try {
            await m.reply(global.mess.wait);
            const results = await scrapeMcpedlSearch(q);
            
            if (!results || results.length === 0) {
                return m.reply(`No results found for "${q}".`);
            }

            let replyText = `*MCPEDL Search Results for "${q}"*\n\n`;
            results.slice(0, 5).forEach((item, index) => {
                replyText += `*${index + 1}. ${item.title}*\n`;
                replyText += `Rating: ${item.rating || 'N/A'}\n`;
                replyText += `Link: ${item.link}\n\n`;
            });

            await m.reply(replyText.trim());

        } catch (error) {
            console.error(error);
            await m.reply(`An error occurred: ${error.message}`);
        }
    }
};