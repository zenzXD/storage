const axios = require("axios");
const FormData = require("form-data");
const { fileTypeFromBuffer } = require("file-type");

const ALLOWED_IMAGE_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/gif",
  "image/webp",
  "image/bmp",
  "image/tiff",
  "image/svg+xml",
];

async function validateImageBuffer(buffer) {
  try {
    const fileType = await fileTypeFromBuffer(buffer);
    if (!fileType) {
      throw new Error("Could not detect file type");
    }
    if (!ALLOWED_IMAGE_TYPES.includes(fileType.mime)) {
      throw new Error(
        `Unsupported file type: ${fileType.mime}. Only image files are allowed.`,
      );
    }
    return {
      isValid: true,
      mime: fileType.mime,
      ext: fileType.ext,
    };
  } catch (error) {
    return {
      isValid: false,
      error: error.message,
    };
  }
}

async function processImageIdentification(imageBuffer) {
  const form = new FormData();
  form.append("image", imageBuffer, {
    filename: "anime.jpg",
    contentType: "image/jpeg",
  });

  try {
    const response = await axios.post(
      "https://www.animefinder.xyz/api/identify",
      form,
      {
        headers: {
          ...form.getHeaders(),
          "Origin": "https://www.animefinder.xyz",
          "Referer": "https://www.animefinder.xyz/",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
    );

    return response.data;
  } catch (error) {
    console.error("API Error:", error.message);
    throw new Error(
      error.response?.data?.error || "Failed to identify anime from image",
    );
  }
}

module.exports = {
    name: 'whatanime',
    alias: ['whatani', 'findanime'],
    category: 'other',
    use: 'all',

    run: async ({ adibot, m, q }) => {
        const isQuotedImage = m.quoted && m.quoted.mimetype.startsWith('image/');
        const isQuotedSticker = m.quoted && m.quoted.mimetype.startsWith('image/webp');
        const url = q.trim();

        if (!isQuotedImage && !isQuotedSticker && !url) {
            return m.reply('Please reply to an image or sticker, or provide an image URL.\n\n*Example:* .whatanime <image_url>');
        }

        try {
            await m.reply(global.mess.wait);
            let imageBuffer;

            if (isQuotedImage || isQuotedSticker) {
                imageBuffer = await m.quoted.download();
            } else {
                try {
                    const response = await axios.get(url, { responseType: 'arraybuffer' });
                    imageBuffer = response.data;
                } catch (urlError) {
                    return m.reply('Failed to fetch image from the provided URL.');
                }
            }

            const validation = await validateImageBuffer(imageBuffer);
            if (!validation.isValid) {
                return m.reply(`Invalid file: ${validation.error}`);
            }

            const result = await processImageIdentification(imageBuffer);

            let caption = `*Anime Identification Result*\n\n`;
            caption += `*Title:* ${result.animeTitle || 'N/A'}\n`;
            caption += `*Character:* ${result.character || 'N/A'}\n`;
            caption += `*Genres:* ${result.genres ? result.genres.join(', ') : 'N/A'}\n`;
            caption += `*Premiere:* ${result.premiereDate || 'N/A'}\n`;
            caption += `*Production:* ${result.productionHouse || 'N/A'}\n\n`;
            caption += `*Synopsis:*\n${result.synopsis || 'N/A'}`;

            await adibot.sendMessage(m.key.remoteJid, {
                image: imageBuffer,
                caption: caption,
            }, { quoted: m });

        } catch (error) {
            console.error(error);
            await m.reply(`An error occurred: ${error.message}`);
        }
    }
};