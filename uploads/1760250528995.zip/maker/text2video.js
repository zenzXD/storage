const axios = require('axios');
const FormData = require('form-data');

const aiLabs = {
  api: {
    base: 'https://text2video.aritek.app',
    endpoints: {
      text2img: '/text2img',
      generate: '/txt2videov3',
      video: '/video'
    }
  },

  headers: {
    'user-agent': 'NB Android/1.0.0',
    'accept-encoding': 'gzip',
    'content-type': 'application/json',
    authorization: ''
  },

  state: {
    token: null
  },

  setup: {
    cipher: 'hbMcgZLlzvghRlLbPcTbCpfcQKM0PcU0zhPcTlOFMxBZ1oLmruzlVp9remPgi0QWP0QW',
    shiftValue: 3,

    dec(text, shift) {
      return [...text].map(c =>
        /[a-z]/.test(c)
          ? String.fromCharCode((c.charCodeAt(0) - 97 - shift + 26) % 26 + 97)
          : /[A-Z]/.test(c)
          ? String.fromCharCode((c.charCodeAt(0) - 65 - shift + 26) % 26 + 65)
          : c
      ).join('');
    },

    decrypt: async () => {
      if (aiLabs.state.token) return aiLabs.state.token;

      const input = aiLabs.setup.cipher;
      const shift = aiLabs.setup.shiftValue;
      const decrypted = aiLabs.setup.dec(input, shift);

      aiLabs.state.token = decrypted;
      aiLabs.headers.authorization = decrypted;
      return decrypted;
    }
  },

  deviceId() {
    return Array.from({ length: 16 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
  },

  generate: async ({ prompt = '', isPremium = 1 } = {}) => {
    await aiLabs.setup.decrypt();
    const payload = {
      deviceID: aiLabs.deviceId(),
      isPremium,
      prompt,
      used: [],
      versionCode: 59
    };

    try {
      const url = aiLabs.api.base + aiLabs.api.endpoints.generate;
      const res = await axios.post(url, payload, { headers: aiLabs.headers });

      const { code, key } = res.data;
      if (code !== 0 || !key || typeof key !== 'string') {
        return { success: false, error: 'Heumm.. Gagal bree ngambil Keynya 🫵🏻🐷' };
      }
      return { success: true, key: key };
    } catch (err) {
      return { success: false, error: err.message || 'Error bree... 😂' };
    }
  },

  video: async (key, m) => {
    if (!key || typeof key !== 'string') {
      return { success: false, error: 'Keynya kagak valid bree... 😏😂' };
    }

    await aiLabs.setup.decrypt();
    const payload = { keys: [key] };
    const url = aiLabs.api.base + aiLabs.api.endpoints.video;
    const maxAttempts = 100;
    const delay = 3000;
    let attempt = 0;
    let lastProgress = -1;

    let statusMessage = await m.reply('⏳ Santai aja dulu gasih, videonya lagi diproses... ');

    while (attempt < maxAttempts) {
      attempt++;
      try {
        const res = await axios.post(url, payload, {
          headers: aiLabs.headers,
          timeout: 15000
        });

        const { code, datas } = res.data;
        if (code === 0 && Array.isArray(datas) && datas.length > 0) {
          const data = datas[0];
          if (!data.url || data.url.trim() === '') {
            const progress = Math.round(parseFloat(data.progress || 0));
            if (progress > lastProgress) {
                 await m.adibot.sendMessage(m.from, { text: `⚡ Generating: ${progress}%`, edit: statusMessage.key });
                 lastProgress = progress;
            }
            await new Promise(r => setTimeout(r, delay));
            continue;
          }
          await m.adibot.sendMessage(m.from, { text: `✅ Videonya dah jadi nih 🤭`, edit: statusMessage.key });
          return { success: true, url: data.url.trim() };
        }
      } catch (err) {
        const retry = ['ECONNRESET', 'ECONNABORTED', 'ETIMEDOUT'].includes(err.code);
        if (retry && attempt < maxAttempts) {
          await new Promise(r => setTimeout(r, delay));
          continue;
        }
        return { success: false, error: 'Error bree...', attempt };
      }
    }
    return { success: false, error: 'Proses videonya kelamaan, keknya lagi ngambek tuh Server AI nya wkwk... ', attempt };
  }
};


module.exports = {
    name: 'aitovideo',
    alias: ['t2v', 'text2video'],
    category: 'maker',
    use: 'all',
    
    run: async ({ adibot, m, q, from }) => {
        if (!q) {
            return m.reply("Masukan prompt atau teks untuk membuat video!\nContoh: .aitovideo a cat driving a car");
        }
        if (!/^[a-zA-Z0-9\s.,!?'-]+$/.test(q)) {
            return m.reply("Promptnya kagak boleh ada karakternya aneh begitu :v kagak boleh yak 😂");
        }

        try {
            const genResult = await aiLabs.generate({ prompt: q });

            if (!genResult.success) {
                return m.reply(genResult.error || "Gagal mendapatkan kunci untuk pembuatan video.");
            }
            
            const videoResult = await aiLabs.video(genResult.key, { adibot, m, from });
            
            if (!videoResult.success) {
                return m.reply(videoResult.error || "Gagal memproses video setelah beberapa percobaan.");
            }

            await adibot.sendMessage(from, { 
                video: { url: videoResult.url }, 
                caption: `*Prompt:* ${q}` 
            }, { quoted: m });

        } catch (e) {
            console.error("AI to Video Error:", e);
            m.reply("Terjadi kesalahan internal saat membuat video.");
        }
    }
};