const axios = require('axios');

module.exports = {
    name: 'carbon',
    alias: ['carbonify'],
    category: 'maker',
    use: 'all',

    run: async ({ adibot, m, q }) => {
        let code;

        if (m.quoted && m.quoted.body) {
            code = m.quoted.body;
        } else if (q) {
            code = q;
        } else {
            return m.reply('Gunakan format .carbon <code> atau balas pesan berisi kode dengan .carbon');
        }

        if (!code.trim()) {
            return m.reply('Kode tidak boleh kosong.');
        }

        try {
            await m.reply(global.mess.wait);

            const response = await axios.post('https://carbonara.solopov.dev/api/cook', 
                { code: code },
                {
                    headers: { 'Content-Type': 'application/json' },
                    responseType: 'arraybuffer'
                }
            );

            const imageBuffer = Buffer.from(response.data);

            if (imageBuffer.length < 1000) {
                 return m.reply('Gagal membuat gambar, API mungkin sedang down.');
            }

            await adibot.sendMessage(m.key.remoteJid, {
                image: imageBuffer,
                caption: 'Carbon.now.sh'
            }, { quoted: m });

        } catch (e) {
            console.error(e);
            await m.reply('Terjadi kesalahan saat menghubungi API Carbon.');
        }
    }
};