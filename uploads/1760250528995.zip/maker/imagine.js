const axios = require('axios');

const imagen = {
 api: {
 base: 'https://image.pollinations.ai',
 endpoints: {
 textToImage: (prompt, width, height, seed) =>
 `/prompt/${encodeURIComponent(prompt)}?width=${width}&height=${height}&nologo=true&safe=true&seed=${seed}`
 }
 },
 headers: {
 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
 'accept': 'image/jpeg',
 'referer': 'https://image.pollinations.ai/'
 },
 stylePrompts: {
 'no style': '{prompt}',
 'realistic': 'realistic photo {prompt}, highly detailed, high budget, highly details, epic, high quality',
 'ghibli': 'style of studio ghibli, Hayao Miyazaki style, {prompt}',
 'gta': 'GTA style {prompt}, Realistic gta art style, rockstar games artwork, vice city, photorealistic concept art, detailed face, realistic anatomy, epic, cinematic, high detail, highly detailed, 4k RAW',
 'anime': 'anime style {prompt}, key visual, vibrant, studio anime, highly detailed',
 'cinematic': 'cinematic still {prompt}, emotional, harmonious, vignette, highly detailed, high budget, bokeh, cinemascope, moody, epic, gorgeous, film grain, grainy',
 'photographic': 'cinematic photo {prompt}, 35mm photograph, film, bokeh, professional, 4k, highly detailed',
 'fantasy': 'ethereal fantasy concept art of {prompt}, magnificent, celestial, ethereal, painterly, epic, majestic, magical, fantasy art, cover art, dreamy',
 'cartoon': 'cartoon style {prompt}, cartoon, vibrant, high-energy, detailed',
 'cyberpunk': 'cyberpunk style {prompt}, extremely detailed, photorealistic, 8k, realistic, neon ambiance, vibrant, high-energy, cyber, futuristic',
 'manga': 'manga style {prompt}, vibrant, high-energy, detailed, iconic, Japanese comic style',
 'digital art': 'concept art {prompt}, digital artwork, illustrative, painterly, matte painting, highly detailed',
 'colorful': 'colorful style {prompt}, color, vibrant, high-energy, detailed, cover art, dreamy',
 'robot': 'robotic style {prompt}, robotic, vibrant, high-energy, detailed, cyber, futuristic',
 'neonpunk': 'neonpunk style {prompt}, cyberpunk, vaporwave, neon, vibes, vibrant, stunningly beautiful, crisp, detailed, sleek, ultramodern, magenta highlights, dark purple shadows, high contrast, cinematic, ultra detailed, intricate, professional',
 'pixel art': 'pixel-art style {prompt}, low-res, blocky, 8-bit graphics, 16-bit, pixel',
 'disney': 'disney style {prompt}, disney cartoon, vibrant, high-energy, detailed, 3d, disney styles',
 '3d model': 'professional 3d model {prompt}, octane render, highly detailed, volumetric, dramatic lighting',
 },
 request: function(prompt, type) {
 const extraPrompt = (this.stylePrompts[type] || '{prompt}').replace('{prompt}', prompt);
 const dimensions = [1024, 1024];
 return { extraPrompt, dimensions };
 },
 generate: async function(prompt = '', type = 'no style') {
 if (!prompt?.trim()) {
 return { success: false, error: 'Prompt tidak boleh kosong.' };
 }
 try {
 const { extraPrompt, dimensions } = this.request(prompt, type);
 const seed = Math.floor(Math.random() * Number.MAX_SAFE_INTEGER);
 const url = `${this.api.base}${this.api.endpoints.textToImage(extraPrompt, dimensions[0], dimensions[1], seed)}`;
 const { data } = await axios.get(url, {
 headers: this.headers,
 timeout: 90000,
 responseType: 'arraybuffer'
 });
 if (!data || data.length === 0) {
 return { success: false, error: 'API tidak memberikan respons gambar.' };
 }
 return { success: true, buffer: data };
 } catch (error) {
 console.error("Imagen Error:", error);
 return { success: false, error: 'Terjadi kesalahan saat menghubungi API.' };
 }
 }
};

module.exports = {
 name: 'imagine',
 alias: ['ai-image', 'pollinations'],
 category: 'maker',
 use: 'all',

 run: async ({ adibot, m, q }) => {
 const styles = Object.keys(imagen.stylePrompts);

 if (!q || q.trim().toLowerCase() === 'styles') {
 let styleList = 'Gunakan format: .imagine style | prompt\n\n';
 styleList += 'Contoh: .imagine anime | a girl with cat ears\n\n';
 styleList += 'Daftar Style yang Tersedia:\n';
 styleList += styles.map(s => `• ${s}`).join('\n');
 return m.reply(styleList);
 }

 let style = 'no style';
 let prompt = q.trim();

 if (q.includes('|')) {
 const parts = q.split('|');
 const potentialStyle = parts[0].trim().toLowerCase();
 if (styles.includes(potentialStyle)) {
 style = potentialStyle;
 prompt = parts.slice(1).join('|').trim();
 }
 }

 if (!prompt) {
 return m.reply('Prompt tidak boleh kosong.');
 }

 try {
 await m.reply(global.mess.wait);
 const result = await imagen.generate(prompt, style);

 if (!result.success) {
 return m.reply(`❌ Error: ${result.error}`);
 }

 await adibot.sendMessage(m.key.remoteJid, {
 image: result.buffer,
 caption: `*Prompt:* ${prompt}\n*Style:* ${style}`
 }, { quoted: m });

 } catch (e) {
 console.error(e);
 await m.reply(global.mess.error);
 }
 }
};