// --- Inisialisasi Data dari Local Storage ---
let saldo = parseFloat(localStorage.getItem('tabunganSaldo')) || 0;
let riwayatTransaksi = JSON.parse(localStorage.getItem('tabunganRiwayat')) || [];

// Inisialisasi Target Tabungan dari Local Storage (FITUR BARU)
let target = parseFloat(localStorage.getItem('tabunganTargetJumlah')) || 500000; // Default Rp 500.000
let namaTarget = localStorage.getItem('tabunganTargetNama') || 'Beli Buku Baru'; // Default Nama Target

// Ambil Elemen DOM
const saldoDisplay = document.getElementById('saldoDisplay');
const targetDisplay = document.getElementById('targetDisplay');
const targetNamaDisplay = document.getElementById('targetNamaDisplay'); // Elemen untuk nama target
const jumlahUangInput = document.getElementById('jumlahUang');
const tombolTabung = document.getElementById('tombolTabung');
const tombolTarik = document.getElementById('tombolTarik');
const riwayatList = document.getElementById('riwayatList');

// Elemen Modal Ubah Target
const modalTargetElement = document.getElementById('modalTarget');
const modalTarget = new bootstrap.Modal(modalTargetElement);
const formUbahTarget = document.getElementById('formUbahTarget');
const namaTargetInput = document.getElementById('namaTargetInput');
const jumlahTargetBaruInput = document.getElementById('jumlahTargetBaruInput');

// --- Fungsi Utilitas ---

// Memformat angka menjadi Rupiah (contoh: Rp 1.000.000)
function formatRupiah(angka) {
    return 'Rp ' + parseFloat(angka).toLocaleString('id-ID');
}

// Memperbarui tampilan saldo dan target
function updateDisplay() {
    saldoDisplay.textContent = formatRupiah(saldo);
    
    // Hitung progress bar (untuk target)
    const progress = Math.min(100, (saldo / target) * 100);
    
    // Update tampilan Target
    targetNamaDisplay.textContent = namaTarget;
    targetDisplay.innerHTML = `${formatRupiah(saldo)} / ${formatRupiah(target)} 
        <div class="progress mt-2" style="height: 10px;">
            <div class="progress-bar bg-warning" role="progressbar" style="width: ${progress}%" aria-valuenow="${progress}" aria-valuemin="0" aria-valuemax="100"></div>
        </div>`;

    // Simpan data ke Local Storage
    localStorage.setItem('tabunganSaldo', saldo);
    localStorage.setItem('tabunganTargetJumlah', target); // Simpan jumlah target
    localStorage.setItem('tabunganTargetNama', namaTarget); // Simpan nama target
    localStorage.setItem('tabunganRiwayat', JSON.stringify(riwayatTransaksi.slice(0, 10)));
    
    renderRiwayat();
}

// Menambahkan riwayat transaksi baru
function tambahRiwayat(tipe, jumlah) {
    const tanggal = new Date().toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    
    const riwayatBaru = {
        tipe: tipe,
        jumlah: jumlah,
        tanggal: tanggal,
        id: Date.now()
    };

    riwayatTransaksi.unshift(riwayatBaru);
}

// Menampilkan riwayat transaksi ke daftar
function renderRiwayat() {
    riwayatList.innerHTML = '';
    
    if (riwayatTransaksi.length === 0) {
        riwayatList.innerHTML = '<li class="list-group-item text-center text-muted">Belum ada riwayat transaksi. Ayo mulai menabung!</li>';
        return;
    }

    // Tampilkan 10 riwayat terbaru
    riwayatTransaksi.slice(0, 10).forEach(item => {
        const listItem = document.createElement('li');
        listItem.className = 'list-group-item';
        
        const tipeKelas = item.tipe === 'Setor' ? 'riwayat-setor' : 'riwayat-tarik';
        const tanda = item.tipe === 'Setor' ? '+' : '-';
        const ikon = item.tipe === 'Setor' ? '<i class="fas fa-plus-circle me-1"></i>' : '<i class="fas fa-minus-circle me-1"></i>';

        listItem.innerHTML = `
            <div>
                ${ikon} ${item.tipe}
                <span class="d-block text-muted small">${item.tanggal}</span>
            </div>
            <span class="${tipeKelas}">${tanda} ${formatRupiah(item.jumlah)}</span>
        `;
        riwayatList.appendChild(listItem);
    });
}

// --- Logika Transaksi ---

tombolTabung.addEventListener('click', function() {
    const jumlah = parseFloat(jumlahUangInput.value);

    if (isNaN(jumlah) || jumlah < 1000) {
        alert('Setoran minimal Rp 1.000!');
        return;
    }

    saldo += jumlah;
    tambahRiwayat('Setor', jumlah);
    updateDisplay();
    jumlahUangInput.value = '';
    alert(`Setoran berhasil! ${formatRupiah(jumlah)} telah ditambahkan. Saldo: ${formatRupiah(saldo)}`);
});

tombolTarik.addEventListener('click', function() {
    const jumlah = parseFloat(jumlahUangInput.value);

    if (isNaN(jumlah) || jumlah < 1000) {
        alert('Penarikan minimal Rp 1.000!');
        return;
    }

    if (jumlah > saldo) {
        alert('Saldo tidak cukup untuk penarikan ini.');
        return;
    }

    saldo -= jumlah;
    tambahRiwayat('Tarik', jumlah);
    updateDisplay();
    jumlahUangInput.value = '';
    alert(`Penarikan berhasil! ${formatRupiah(jumlah)} telah ditarik. Saldo: ${formatRupiah(saldo)}`);
});

// --- Logika Ubah Target (FITUR BARU) ---

// Mengisi formulir modal dengan data target saat ini sebelum dibuka
modalTargetElement.addEventListener('show.bs.modal', function() {
    namaTargetInput.value = namaTarget;
    jumlahTargetBaruInput.value = target;
});

// Menangani submit formulir Ubah Target
formUbahTarget.addEventListener('submit', function(e) {
    e.preventDefault(); 
    
    const namaBaru = namaTargetInput.value.trim();
    const jumlahBaru = parseFloat(jumlahTargetBaruInput.value);

    if (namaBaru === "" || isNaN(jumlahBaru) || jumlahBaru < 10000) {
        alert('Pastikan nama target terisi dan jumlah target minimal Rp 10.000.');
        return;
    }

    // Perbarui variabel global
    namaTarget = namaBaru;
    target = jumlahBaru;

    // Perbarui tampilan dan simpan data
    updateDisplay(); 
    
    // Tutup modal dan beri notifikasi
    modalTarget.hide();
    alert(`Target tabungan berhasil diubah menjadi "${namaTarget}" dengan jumlah ${formatRupiah(target)}!`);
});


// Panggil fungsi ini saat aplikasi pertama kali dimuat
updateDisplay();
