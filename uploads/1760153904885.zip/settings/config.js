global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6282382166487']
global.packname = "CrasherV13"
global.author = "CrasherV13"
global.mess = {
 owner: '*BUKAN OWNER BEGO 🥱*',
 premium: '*BUKAN PREM BEGO 🥱*'
}